from collections import Counter 
import os
import math

def train(training_directory, cutoff):
    model={}
    vocab=create_vocabulary(training_directory,cutoff)
    training_data=load_training_data(vocab,training_directory)
    model['vocabulary']=vocab
    model['log prior']=prior(training_data,['2016','2020'])
    model['log p(w|y=2016)']=p_word_given_label(vocab,training_data,'2016')
    model['log p(w|y=2020)']=p_word_given_label(vocab,training_data,'2020')
    return model

def create_vocabulary(training_directory, cutoff):
    word_list=[]
    for file in os.listdir(training_directory+"2016/"):
        f = open (training_directory+"2016/"+file,'r', encoding='utf-8')
        for x in f:
            word_list.append(x)

    
            
    for file in os.listdir(training_directory+"2020/"):
        
        f= open(training_directory+"2020/"+file,'r', encoding='utf-8')
        for x in f:
            word_list.append(x)

    cnt=Counter(word_list)
    final_list=[]
    for x in cnt:
        if cnt[x] >= cutoff:
            final_list.append(x.strip('\n'))
    final_list.sort()
    return final_list




def create_bow(vocab, filepath):
    f=open(filepath,'r', encoding='utf-8')
    word_list=[]
    none_list=[]
    count=0
    for x in f:
        word_list.append(x.strip('\n'))

    cnt=Counter(word_list)
    bow=dict(cnt)
    #print(bow)
    for key in bow:
        if key not in vocab:
            none_list.append(key)
            count=count+bow[key]

    for key in none_list:
        del bow[key]
    if count!=0:
        bow[None]=count
    return bow
            

def load_training_data(vocab, directory):
    result=[]
    for file in os.listdir(directory+"2016/"):
        individual_dict={}
        individual_dict['label']="2016"
        individual_dict ['bow']=  create_bow(vocab,directory+"2016/"+file)
        result.append(individual_dict)

    for file in os.listdir(directory+"2020/"):
        individual_dict={}
        individual_dict['label']="2020"
        individual_dict ['bow']=  create_bow(vocab,directory+"2020/"+file)
        result.append(individual_dict)
        
    return result


def prior(training_data, label_list):

    #always 2016 and 2020 as labels?
    count_0=0
    count_1=0
    for x in training_data:
        if x['label']==label_list[0]:
            count_0=count_0+1

        else:
            count_1=count_1+1

    prob_0=math.log(count_0/len(training_data))
    prob_1=math.log(count_1/len(training_data))
    result={label_list[0]:prob_0,label_list[1]:prob_1}
    
    return result


def p_word_given_label(vocab, training_data, label):
    bow_data=[]#all the dicts of the label
    result={}
    prob={}
    total_words=0
    for key in vocab:
        result[key]=0
    result[None]=0
    
    
    for x in training_data:
        if x['label']==label:
            bow_data.append(x['bow'])
    
    for x in bow_data:
        for key in x:
            if key in vocab:
                result[key]=result[key]+x[key]
            else:
                result[None]=result[None]+x[key]
    
    for key in result:
       total_words=total_words+result[key]
    
    
    for key in result:
        prob[key]=math.log((result[key]+1)/(total_words+len(vocab)+1))
    
    
            
    return prob


def classify(model, filepath):
    sum_2016=0
    sum_2020=0
    prior=model['log prior']
    prob_in_label_2016=model['log p(w|y=2016)']
    prob_in_label_2020=model['log p(w|y=2020)']
    result={}
    bow=create_bow(model['vocabulary'],filepath)
    for key in bow:
        sum_2016=sum_2016+bow[key]*prob_in_label_2016[key]
    sum_2016=sum_2016+prior['2016']

    for key in bow:
        sum_2020=sum_2020+bow[key]*prob_in_label_2020[key]
    sum_2020=sum_2020+prior['2020']
    if sum_2020>sum_2016:
        
        result['predicted y']='2020'
    else:
        result['predicted y']='2016'
    result['log p(y=2016|x)']=sum_2016
    result['log p(y=2020|x)']=sum_2020
    
    
    return result


    
