import random

def create_envelope():
    index=random.randint(0,3)
    balls=["b","b","b","b"]
    balls[index]="r"
    envelope_1=[balls[0],balls[1]]
    envelope_2=[balls[2],balls[3]]
    envelopes=[]
    envelopes.append(envelope_1)
    envelopes.append(envelope_2)
    return envelopes


    

def pick_envelope(switch, verbose):
    envelopes=create_envelope()
    envelope_0=envelopes[0]
    envelope_1=envelopes[1]
    if verbose==True:
        print("Envelope 0:",envelope_0[0],envelope_0[1])
        print("Envelope 1:",envelope_1[0],envelope_1[1])
    picked_envelope= envelopes[random.randint(0,1)]
    if verbose==True:
        print("I picked envelope",envelopes.index(picked_envelope))
    if picked_envelope[random.randint(0,1)]=="r":
        if verbose==True:
            print("and drew a r")
        return True

    else:
        if verbose== True:            
            print("and drew a b")
        if switch==True:
            remain_envelope=envelopes[envelopes.index(picked_envelope)-1]
            if verbose==True:                
                print("Switch to envelope",envelopes.index(remain_envelope))
            if "r" in remain_envelope:
                return True
            
        else:
            if "r" in picked_envelope:#since one ball is checked, the other ball is garanteed to be checked
                return True
            return False
        



def run_simulation(n):
    count_1=0
    count_2=0
    for i in range(n):
        if pick_envelope(True,False)==True:
            count_1=count_1+1

        if pick_envelope(False,False)==True:
            count_2=count_2+1

    success_1=count_1/n*100
    success_2=count_2/n*100
    print("After",n,"simulations:")
    print("  Switch successful:",success_1,"%")
    print("  No-switch successful:",success_2,"%")
        




    


